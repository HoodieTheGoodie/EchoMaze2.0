# Assets Folder

Place custom sprite images here:
- bazooka.png - Bazooka weapon pickup sprite
- generator.png - Generator tile sprite  
- ammo_crate.png - Ammo crate pickup sprite

Images should have transparent backgrounds (PNG format recommended).
