Echo Maze 2.0 - CrazyGames Upload
---------------------------------
- HTML5 game, no external links
- index.html is the main entry (no redirects)
- All assets are local (css/js/assets)
- Works offline; no analytics or tracking
